package io.openfednow.gateway;

import io.openfednow.iso20022.Camt029Message;
import io.openfednow.iso20022.Camt056Message;
import io.openfednow.iso20022.Pacs002Message;
import io.openfednow.iso20022.Pacs008Message;
import io.openfednow.processing.cancellation.CancellationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Layer 1 — API Gateway &amp; Security (RTP® rail)
 *
 * <p>Provides local RTP-shaped inbound reference routing; live network access
 * and the applicable message profile have not been verified.
 * Outbound initiation is disabled pending equivalent financial controls.
 *
 * <h2>Inbound path ({@code /rtp/receive})</h2>
 * <p>Accepts an ISO 20022 pacs.008.001.08 credit transfer in either XML
 * ({@code application/xml}, locally modeled XML envelope) or JSON
 * ({@code application/json}, for sandbox/simulator testing). After parsing,
 * the message is routed through the shared {@link MessageRouter} that also
 * handles FedNow messages. When the inbound format was XML, the pacs.002
 * status report is serialized back to XML via {@link RtpXmlSerializer}.
 *
 * <h2>Outbound path ({@code /rtp/send})</h2>
 * <p>Returns HTTP 503 without financial effects. Serialization and client
 * utilities remain available for synthetic tests and existing return paths.
 *
 * <h2>Certificate validation</h2>
 * <p>An inbound certificate-check hook is handled by
 * {@link CertificateManager#validateTchClientCertificate()}. In dev/sandbox mode
 * (no {@code TCH_TRUSTSTORE_PATH} configured), validation is skipped. In
 * production, TCH PKI certificates and private-network transport are obtained
 * through TCH institutional onboarding — the same class of credential dependency
 * as Federal Reserve PKI for the FedNow rail.
 *
 * @see FedNowGateway
 * @see RtpXmlParser
 * @see RtpXmlSerializer
 * @see <a href="../../../../../../../../docs/rtp-compatibility.md">rtp-compatibility.md</a>
 * @see <a href="../../../../../../../../docs/adr/0005-dual-rail-architecture-fednow-rtp.md">ADR-0005</a>
 */
@RestController
@RequestMapping("/rtp")
@Tag(
    name = "RTP Gateway",
    description = """
        RTP® inbound reference gateway; outbound payment initiation is disabled. \
        Inbound: accepts application/xml (locally modeled envelope via RtpXmlParser) \
        or application/json (sandbox/simulator); routes through the shared Layers 2–4 pipeline; \
        returns pacs.002 in the same format as the request. \
        Outbound: /rtp/send returns HTTP 503 without submitting a payment; transport utilities use RtpClient \
        (SandboxRtpClient by default; HttpRtpClient when RTP_ENDPOINT is set). \
        Live TCH message/security behavior and private-network transport require \
        applicable specifications and institutional onboarding. \
        See docs/rtp-compatibility.md and ADR-0005."""
)
public class RtpGateway {

    private final MessageRouter messageRouter;
    private final CertificateManager certificateManager;
    private final RtpXmlParser rtpXmlParser;
    private final RtpXmlSerializer rtpXmlSerializer;
    private final RtpClient rtpClient;
    private final CancellationService cancellationService;

    public RtpGateway(MessageRouter messageRouter, CertificateManager certificateManager,
                      RtpXmlParser rtpXmlParser, RtpXmlSerializer rtpXmlSerializer,
                      RtpClient rtpClient, CancellationService cancellationService) {
        this.messageRouter = messageRouter;
        this.certificateManager = certificateManager;
        this.rtpXmlParser = rtpXmlParser;
        this.rtpXmlSerializer = rtpXmlSerializer;
        this.rtpClient = rtpClient;
        this.cancellationService = cancellationService;
    }

    /**
     * Accepts an inbound RTP pacs.008 credit transfer and returns a pacs.002 status report.
     *
     * <p>Accepts:
     * <ul>
     *   <li>{@code application/xml} — locally modeled ISO 20022 XML envelope;
     *       response is also returned as XML ({@code application/xml})</li>
     *   <li>{@code application/json} — JSON pacs.008 (for sandbox / compatibility testing);
     *       response is returned as JSON</li>
     * </ul>
     *
     * <p>After parsing, the {@link Pacs008Message} is routed through the same
     * {@link MessageRouter} used by the FedNow gateway — Layers 2–4 are rail-agnostic.
     * TCH certificate validation is applied via
     * {@link CertificateManager#validateTchClientCertificate()} (no-op in sandbox mode).
     */
    @PostMapping(value = "/receive",
                 consumes = {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE})
    @Operation(
        summary = "Receive inbound credit transfer (RTP)",
        description = """
            Accepts an inbound pacs.008.001.08 FI-to-FI credit transfer. \
            Accepts application/xml (locally modeled ISO 20022 XML, parsed by RtpXmlParser \
            and responded to with pacs.002 XML) or application/json (sandbox/compatibility). \
            A certificate-validation hook is called; without a configured truststore, \
            it is a no-op. This does not establish live RTP compatibility."""
    )
    @ApiResponses({
        @ApiResponse(
            responseCode = "200",
            description = "Local status fixture; not a verified live RTP outcome",
            content = @Content(mediaType = "application/json",
                               schema = @Schema(implementation = Pacs002Message.class))),
        @ApiResponse(responseCode = "400",
            description = "Malformed or schema-invalid ISO 20022 pacs.008 XML/JSON"),
        @ApiResponse(responseCode = "503",
            description = "Local processing dependency unavailable")
    })
    public ResponseEntity<?> receiveTransfer(
            @RequestBody String rawBody,
            @RequestHeader(value = "Content-Type", defaultValue = "application/json") String contentType) {

        certificateManager.validateTchClientCertificate();

        Pacs008Message message;
        boolean isXml = contentType.contains(MediaType.APPLICATION_XML_VALUE);

        if (isXml) {
            message = rtpXmlParser.parse(rawBody);
        } else {
            try {
                message = new com.fasterxml.jackson.databind.ObjectMapper()
                        .registerModule(new com.fasterxml.jackson.datatype.jsr310.JavaTimeModule())
                        .readValue(rawBody, Pacs008Message.class);
            } catch (com.fasterxml.jackson.core.JsonProcessingException e) {
                return ResponseEntity.badRequest().build();
            }
        }

        ResponseEntity<Pacs002Message> routerResponse = messageRouter.routeInbound(message, Rail.RTP);

        // When the inbound message was XML, return the locally modeled
        // pacs.002 status report as XML. For sandbox/JSON
        // requests, return JSON — the same format used by the FedNow gateway.
        if (isXml && routerResponse.getBody() != null) {
            String responseXml = rtpXmlSerializer.serializePacs002(routerResponse.getBody());
            return ResponseEntity.status(routerResponse.getStatusCode())
                    .contentType(MediaType.APPLICATION_XML)
                    .body(responseXml);
        }

        return routerResponse;
    }

    /**
     * Outbound RTP is outside the evaluated release. The previous direct-client
     * path bypassed screening, funds reservation, and idempotency. Keep the
     * endpoint explicit but unavailable until equivalent controls are validated.
     */
    @PostMapping("/send")
    @Operation(summary = "Outbound RTP unavailable in this evaluation release")
    @ApiResponse(responseCode = "503", description = "Outbound RTP controls not implemented")
    public ResponseEntity<Pacs002Message> sendTransfer(@RequestBody Pacs008Message message) {
        return ResponseEntity.status(503).body(Pacs002Message.rejected(
                message.getEndToEndId(), message.getTransactionId(), "TS01",
                "Outbound RTP disabled: financial controls have not been validated"));
    }

    /**
     * Receives an inbound camt.056 cancellation request via the RTP rail and
     * returns a camt.029 resolution.
     *
     * <p>Rail-agnostic — the same {@link CancellationService} handles RTP and
     * FedNow cancellations because the saga lookup and lifecycle decisions are
     * identical. See ADR-0007 for the decision matrix.
     */
    @PostMapping("/cancellation")
    @Operation(
        summary = "Receive inbound cancellation request (camt.056) — RTP rail",
        description = """
            Accepts a synthetic inbound camt.056-shaped cancellation and returns \
            a local camt.029-shaped resolution. The shared decision code is not \
            a verified live RTP rule mapping — see ADR-0007."""
    )
    @ApiResponses({
        @ApiResponse(
            responseCode = "200",
            description = "Cancellation outcome",
            content = @Content(mediaType = "application/json",
                               schema = @Schema(implementation = Camt029Message.class))),
        @ApiResponse(responseCode = "503",
            description = "Local processing dependency unavailable")
    })
    public ResponseEntity<Camt029Message> receiveCancellation(@RequestBody Camt056Message request) {
        certificateManager.validateTchClientCertificate();
        return ResponseEntity.ok(cancellationService.handleCancellationRequest(request));
    }

    /**
     * Health check for the RTP gateway.
     */
    @GetMapping("/health")
    @Operation(
        summary = "RTP gateway health check",
        description = """
            Returns the current operational status of the RTP gateway. \
            Inbound XML parsing (RtpXmlParser) and XML serialization \
            (RtpXmlSerializer) utilities exist; outbound sends are disabled. HTTP transport is configured by \
            setting RTP_ENDPOINT; in its absence, SandboxRtpClient is active. \
            TCH PKI certificate validation requires TCH_TRUSTSTORE_PATH."""
    )
    @ApiResponse(responseCode = "200", description = "RTP gateway is reachable",
        content = @Content(mediaType = "text/plain",
                           schema = @Schema(type = "string",
                               example = "OpenFedNow RTP Gateway — outbound sends disabled; sandbox mode active")))
    public ResponseEntity<String> health() {
        boolean liveMode = rtpClient instanceof HttpRtpClient;
        String connectivity = liveMode
                ? "HTTP transport configured; live connectivity not verified"
                : "sandbox mode active";
        return ResponseEntity.ok(
                "OpenFedNow RTP Gateway — outbound sends disabled; XML parsing and serialization active; " + connectivity);
    }
}
