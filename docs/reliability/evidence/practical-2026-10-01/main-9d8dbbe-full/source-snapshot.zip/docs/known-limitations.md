# Known Limitations

This document catalogs the genuine limitations of the OpenFedNow framework — both architectural trade-offs that are intentional and implementation gaps that are not yet built. The distinction matters: an architectural trade-off has a documented reason and an accepted consequence; an implementation gap is work that is simply not done yet.

---

## Architecture-Level Limitations

These are observed design and implementation risks. Some behavior is deliberately modeled in the sandbox; its suitability for a live payment service remains unverified.

### 1. Post-reconciliation return behavior is unverified

**What the sandbox models:** If a synthetic core rejects a transaction that the bridge fixture provisionally accepted, the compensation path constructs a pacs.004-shaped return. The return gateway is disabled by default; no live rail submission, settlement or customer-visible result was verified.

**Why this exists:** The architecture accepts ACSP (provisional acceptance) before the core has confirmed. This is a reference behavior, not an established FedNow-compliant response. The official readiness guide describes acceptance without posting using ACWP; the project's ACSP behavior needs review against the applicable operating procedures and message specifications before live use.

**Consequence:** The customer, legal and operational consequences require institution-specific review before any live adaptation. This repository does not establish them.

**Related:** [ADR-0003](adr/0003-provisional-acceptance-acsp.md), [ADR-0004](adr/0004-eventual-consistency-shadow-ledger-and-core.md)

---

### 2. Redis concurrency is not cross-store atomicity

Redis WATCH detects changes to watched keys by **other clients**, including clients on other pods. The previous explanation that WATCH could not coordinate across connections was incorrect. See [Redis transaction documentation](https://redis.io/docs/latest/develop/using-commands/transactions/) (living documentation, reviewed September 23, 2026).

`ShadowLedger.applyDebit` checks and decrements inside WATCH/MULTI/EXEC, then writes its SQL audit record separately. Crashes between these operations, duplicate delivery, retries, and concurrent reversals need cross-store validation. The repository does not establish deployment correctness for either one pod or multiple pods merely by using WATCH. A distributed lock alone would not make Redis and SQL commits atomic.

---

### 3. Reconciliation ordering depends on NTP accuracy

**What happens:** During reconciliation, queued transactions are replayed against the core in `applied_at` timestamp order. Out-of-order replay would post transactions against the wrong intermediate balances (e.g., a $500 withdrawal replayed before the $600 deposit it depends on).

**Why this depends on NTP:** The `applied_at` timestamps are assigned by the middleware using the system clock. If the system clock drifts backward (clock slew, NTP correction), two transactions in the same maintenance window could receive timestamps that do not reflect their true causal order.

**Mitigation in place:** The reconciliation replay queries by `applied_at ASC`, which is correct assuming monotonically increasing timestamps. The middleware does not generate synthetic sequence numbers or vector clocks.

**Risk:** A clock slew large enough to reverse two transactions during a maintenance window would produce incorrect intermediate balances during replay. This is unlikely (NTP slew rate is typically bounded to 500ppm) but not impossible in a misconfigured or VM-heavy environment.

---

### 4. Synthetic ACSP-shaped bridge response relies on a cached balance

**What the sandbox models:** During a simulated maintenance window, the local bridge can return an ACSP-shaped response before the synthetic core has processed the transaction. This is not verified live FedNow behavior. The Redis Shadow Ledger is the fixture's decision input for that window; it cannot establish the bank's true available funds across other channels.

**The unbounded institution-specific risk:** The Shadow Ledger's balance is initialized from the core and updated atomically within Redis on each transaction, but other systems may change the bank's true available balance. Documented sources of divergence include: a core-side rejection of a provisionally accepted payment (see limitation #1 above), and card-processor STIP activity that authorizes debits on the same account outside the Shadow Ledger during the window — the "STIP gap." Other sources of drift, including cross-store crash windows and concurrent external activity, have not been excluded by this evaluation.

**Why this is documented:** The sandbox design temporarily authorizes from a cached balance during a simulated maintenance window. It does not transfer legal or operational authority from an institution's core to this software. The full analysis of the STIP gap and the four-step mitigation roadmap (kill switch, aggregate cap, real-time card authorization port, and configuration postures from receive-only through STIP-aware) is in [ADR-0010](adr/0010-bridge-mode-fraud-risk.md). This should be disclosed in the institution's internal control documentation.

---

## Implementation Gaps

These are features that are not yet built. They are explicitly tracked as future work.

### 5. Vendor compatibility remains unverified

`FiservAdapter`, `FisAdapter`, and `JackHenryAdapter` are vendor-shaped reference implementations. Their local WireMock suites exercise JSON/SOAP construction, authentication and response mapping. They have not been tested in an actual vendor environment and are not verified for any particular product. The [v1 reliability capability matrix](reliability/adapter-capabilities-v1.md) records fixture-only evidence and unsupported all-channel reservation, expiry, posting/reversal deduplication and outcome lookup. The guarded SQL reliability bridge does not call these adapters. A vendor-backed live send must fail closed until an institution establishes the missing capabilities and applicable specifications.

`MockVendorAdapter` has an in-memory balance ledger and configurable failures for local development. It is not a substitute for a real institution core. The existing adapter contract tests cover the narrow `CoreBankingAdapter` methods, not the stronger financial guarantees needed for live outbound payments.

---

### 8. Live FedNow connectivity requires institution-provided credentials

`FedNowClient` is an interface with two implementations:

- **`SandboxFedNowClient`** — active by default (when `FEDNOW_ENDPOINT` is not set). Returns synthetic in-memory responses for local development and testing.
- **`HttpFedNowClient`** — activated when `FEDNOW_ENDPOINT` is set. Provides a synthetic JSON HTTP transport with one attempt for credit transfers and returns, plus optional JWS detached signing (activate via `openfednow.fednow.signing.enabled=true`; see [ADR-0009](adr/0009-fednow-jws-message-signing.md)). It is not a verified live FedNow transport. Production requires the applicable restricted specifications, institution access, authenticated status handling and certification in addition to credentials and mutual TLS.

The `FedNowClientConfig` bean is conditional: `HttpFedNowClient` is only created when `openfednow.gateway.fednow-endpoint` is present. When that property is absent, `SandboxFedNowClient` activates via `@ConditionalOnMissingBean`. This means `mvn spring-boot:run` without any environment variables uses the sandbox client throughout.

---

### 9. Live RTP connectivity requires institution-provided credentials

`RtpClient` is an interface with two implementations, symmetric with `FedNowClient`:

- **`SandboxRtpClient`** — active by default (when `RTP_ENDPOINT` is not set). Returns synthetic in-memory responses for local development and testing.
- **`HttpRtpClient`** — activated when `RTP_ENDPOINT` is set. Serializes pacs.008 to canonical ISO 20022 XML via `RtpXmlSerializer` and POSTs to the configured TCH endpoint. Live RTP production additionally requires TCH PKI client certificates, a dedicated private-network connection to the TCH RTP® network, and institutional participation. These are institution-provided credentials and are outside the scope of the framework.

`RtpClientConfig` is conditional: `HttpRtpClient` is only created when `openfednow.gateway.rtp-endpoint` is present. When absent, `SandboxRtpClient` activates via `@ConditionalOnMissingBean`. The TCH certificate-validation hook is invoked on every request via `CertificateManager.validateTchClientCertificate()`; in sandbox mode (no `TCH_TRUSTSTORE_PATH`) it is a no-op.

Inbound XML parsing, serialization, certificate hooks, and transport utilities exist in reference mode. Outbound RTP previously bypassed router financial controls and is now disabled. Live message semantics and control parity remain unverified. See [rtp-compatibility.md](rtp-compatibility.md) and [ADR-0005](adr/0005-dual-rail-architecture-fednow-rtp.md).

Inbound source rail (FedNow vs. RTP) is now persisted on every `saga_state` row via the `source_rail` column (V5 migration). Asynchronous response paths can therefore dispatch through the correct gateway. The wiring for those asynchronous paths — reconciliation-time pacs.002 notifications and compensation-time pacs.004 returns to the originating rail — is still pending.

---

### 10. Outbound camt.056 is not wired

Inbound cancellation handling is now implemented — see "Cancellation handling" below in the operational capabilities section. The remaining gap is **outbound** cancellation: the institution wanting to recall its own payment via a camt.056 it constructs and submits to FedNow. `Camt056Message.forPaymentCancellation()` builds a valid message, but there is no admin endpoint, no `FedNowClient.submitCancellation()` method, and no async tracking of the resulting camt.029. Tracked as future work.

---

### Kafka event bus (optional, available)

An optional Kafka event bus is available via the `PaymentEventPublisher` interface. When Kafka is configured, `KafkaPaymentEventPublisher` is activated; otherwise `NoOpPaymentEventPublisher` is used by default. Six event types are published: `INBOUND_CREDIT_APPLIED`, `INBOUND_PAYMENT_REJECTED`, `INBOUND_QUEUED_FOR_BRIDGE`, `OUTBOUND_PAYMENT_COMPLETED`, `OUTBOUND_PAYMENT_REJECTED`, and `OUTBOUND_PAYMENT_PENDING`. No Kafka dependency is required to run the framework.

---

## Operational capabilities now available

These are implemented and worth calling out so deployers know what they get without further engineering.

### Saga lifecycle resilience

- **Saga recovery on restart.** `SagaRecoveryService` listens to `ApplicationReadyEvent` and processes legacy in-flight sagas on startup. It quarantines interrupted `SUBMITTING` as `OUTCOME_UNKNOWN`; those unknown obligations remain unresolved rather than being forced terminal. `INITIATED` / `FUNDS_RESERVED` / `CORE_SUBMITTED` sagas are compensated (reason `NARR`); `FEDNOW_CONFIRMED` advances to `COMPLETED`; `COMPENSATING` is finalized to `FAILED` preserving the original reason code.
- **Saga timeout monitor.** `SagaTimeoutMonitor` runs on a fixed schedule (`openfednow.saga.timeout-check-interval-seconds`, default 10) and compensates any saga in a forward-progress state whose `created_at` is older than `openfednow.saga.timeout-seconds` (default 30). Reason code `XPIR` (ISO 20022 Expired) distinguishes timeout-driven failures from restart-recovery failures. Each timeout increments the `saga.timeout` Micrometer counter visible at `/actuator/metrics`.

### Operator endpoints under `/admin`

All `/admin/**` endpoints require HTTP Basic with the `ADMIN` role (`SecurityConfig`). All access — granted, denied, rejected, or error — is recorded in `admin_audit_log` by `AdminAccessAuditFilter`.

| Endpoint | Purpose |
| --- | --- |
| `POST /admin/reconcile` and `POST /admin/reconciliation-runs` | Trigger a manual reconciliation cycle (resource-style alias) |
| `GET /admin/reconciliation-runs[?limit=&offset=]` | Paginated reconciliation history; cap 200 per page |
| `GET /admin/reconciliation-runs/{runId}` | Single reconciliation run; 404 if missing |
| `GET /admin/sagas` | List non-terminal sagas (oldest first) |
| `GET /admin/sagas/{transactionId}` | Saga snapshot by ISO 20022 transaction ID |
| `GET /admin/accounts/{accountId}/balance` | Live Redis balance + unconfirmed-DEBIT total + last transaction timestamp |
| `POST /admin/shadow-ledger/seed` | Re-seed configured accounts from the core (unconditional overwrite) |
| `GET /admin/audit-log[?limit=&offset=]` | Paginated admin access history; cap 500 per page |

### Throughput controls

- **Rate limiting** on `POST /fednow/**` and `POST /rtp/**` via `RateLimitFilter`. Per-client buckets keyed on `X-Forwarded-For` (first hop) or remote address, refreshed every second. Default 100 transfers/sec/client (`openfednow.rate-limit.transfers-per-second`). Rejected requests get HTTP 429 with `Retry-After: 1` and increment `gateway.rate_limited`.
- **Idempotency record retention** is configurable via `openfednow.idempotency.ttl-hours` (default 48); `IdempotencyCleanupService` sweeps expired rows on `openfednow.idempotency.cleanup-interval-minutes` (default 60).

### Balance seeding

`BalanceSeedService` reads `openfednow.shadow-ledger.seed-accounts` (comma-separated). On `ApplicationReadyEvent` it loads each account's balance from the core adapter into Redis using `SETNX` so a recycled middleware pod never clobbers live balances. The on-demand `POST /admin/shadow-ledger/seed` endpoint uses unconditional overwrite for explicit resyncs.

### Fraud pre-screening

`FraudScreeningPort` is the extensibility seam — one method, one structured result, called by `MessageRouter` on every inbound and outbound credit transfer before any side effects.

The default implementation (`DefaultFraudScreeningService`) is opt-in via `openfednow.fraud.enabled=true` and applies four rules in priority order: account denylist (BLOCK), amount cap (BLOCK), debtor velocity via Redis `INCR` + `EXPIRE` (BLOCK), and elevated-amount review at ≥ 50% of the cap (REVIEW — proceeds but flagged in `fraud.reviewed` counter and WARN log). When disabled, `NoOpFraudScreeningService` passes everything through.

Institutions with mature fraud programs are expected to replace the default implementation with their own port implementation calling into a hosted scoring service or ML model. The contract is intentionally narrow so swapping doesn't touch router or message-model code. See [ADR-0008](adr/0008-fraud-screening.md) for the full decision and consequences.

### Cancellation handling (camt.056 / camt.029)

`CancellationService` handles inbound camt.056 cancellation requests on both rails. `POST /fednow/cancellation` and `POST /rtp/cancellation` accept the camt.056 and return the camt.029 synchronously. Decision logic is keyed on the saga state of the original payment:

- INITIATED / FUNDS_RESERVED → CNCL (Shadow Ledger credit reversed if applied; saga moves to FAILED carrying the camt.056 reason code)
- CORE_SUBMITTED / COMPENSATING → PDCR (outcome can't be determined synchronously; operator follow-up may be needed)
- FEDNOW_CONFIRMED / COMPLETED → RJCR / ARDT (settlement is committed; originator must use pacs.004 return)
- FAILED or no saga → RJCR / NOOR

The full decision matrix and design tradeoffs are documented in [ADR-0007](adr/0007-camt056-cancellation-lifecycle.md).

---

## Local Development Limitations

These distinguish the H2-backed default test suite from the PostgreSQL runtime and tagged integration suite.

### 12. H2 is only used by tests — the runtime uses PostgreSQL

The `application.yml` default datasource is PostgreSQL (`jdbc:postgresql://localhost:5432/openfednow`) and `docker-compose.yml` provides that instance. Running the app on H2 is not supported: the idempotency INSERT uses `ON CONFLICT DO NOTHING`, which H2 does not implement even in Postgres-compat mode. The PostgreSQL runtime also holds the synthetic reliability tables from migrations V9–V12. PostgreSQL persistence alone does not establish live rail or core correctness.

H2 is still used by the test suite (see `src/test/resources/application.properties`) so tests remain fast and Docker-free. `@Tag("integration")` tests override that with real Postgres via Testcontainers.

---

### 13. Redis has no replication in docker-compose

The `docker-compose.yml` starts a single Redis node with AOF persistence enabled (`redis-server --appendonly yes`), so Shadow Ledger balances survive a Redis restart. What is **not** configured is replication — a single lost Redis node with an unrecoverable AOF would still drop the ledger.

A real deployment would require an institution-defined durability, failover and recovery design. Replication alone would not make the Redis and PostgreSQL effects atomic or validate cross-channel funds availability.

---

## Related

- [ADR-0001](adr/0001-optimistic-locking-shadow-ledger-debits.md) — why WATCH/MULTI/EXEC (and its single-instance constraint)
- [ADR-0003](adr/0003-provisional-acceptance-acsp.md) — why ACSP is returned, and the exposure window
- [ADR-0004](adr/0004-eventual-consistency-shadow-ledger-and-core.md) — why eventual consistency was chosen over 2PC
- [shadow-ledger.md](shadow-ledger.md) — Shadow Ledger operational detail and failure modes
- [saga-pattern.md](saga-pattern.md) — compensation path for post-reconciliation core rejections

## Evaluation release: unresolved submission outcomes

`UncertainSubmissionReproducerTest` simulates a server receiving a request and delaying its response beyond the client's deadline. Credit transfers now make one HTTP attempt. Before the request, the saga persists `SUBMITTING`; if no valid status arrives, it becomes `OUTCOME_UNKNOWN`. The debit remains reserved, the caller receives HTTP 503 without a synthetic pacs.002, and another request with the same end-to-end ID cannot submit again. Startup recovery moves interrupted `SUBMITTING` sagas to `OUTCOME_UNKNOWN`; the timeout monitor excludes both states. An ACSP response also retains the debit pending final confirmation. The test uses WireMock and mocked financial services; it does not reproduce real settlement.

An operator can locate a legacy saga at `/admin/sagas/{transactionId}` and compare it with an authoritative rail or institution record. That legacy path has no implemented status inquiry or verified resolution action and its gateway send is disabled by default. The separate `/reference/v1/payments` synthetic slice has SQL ownership, holds, inquiry and an external simulator; see [reliability architecture](reliability/architecture.md) and [scenario register](reliability/requirements.csv). Neither path may release funds or retry based only on HTTP status, elapsed time or a synthetic simulator. Live status authentication and institution core capabilities remain unverified.
