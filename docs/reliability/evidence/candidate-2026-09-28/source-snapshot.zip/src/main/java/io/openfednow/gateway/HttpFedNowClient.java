package io.openfednow.gateway;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.github.resilience4j.retry.Retry;
import io.openfednow.gateway.signing.FedNowJwsSigner;
import io.openfednow.iso20022.Pacs002Message;
import io.openfednow.iso20022.Pacs004Message;
import io.openfednow.iso20022.Pacs008Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.List;

/**
 * HTTP implementation of {@link FedNowClient}.
 *
 * <p>POSTs pacs.008 messages as JSON to
 * {@code {fednowEndpoint}/transfers} and deserializes the pacs.002 response.
 * For credit transfers, network and HTTP failures leave the outcome unknown:
 * the client makes one attempt and throws {@link SubmissionOutcomeUnknownException}.
 * Return submissions also make one attempt and preserve ambiguous outcomes.
 *
 * <p>This class is not a {@code @Component}; it is created by
 * {@link FedNowClientConfig} as a Spring bean so the endpoint URL and timeout
 * can be injected from application properties. Tests instantiate it directly
 * via the single public constructor, pointing it at a WireMock base URL.
 */
public class HttpFedNowClient implements FedNowClient {

    private static final Logger log = LoggerFactory.getLogger(HttpFedNowClient.class);

    /** Path appended to the configured base endpoint for credit transfer submission. */
    static final String TRANSFERS_PATH = "/transfers";

    /** Path appended to the configured base endpoint for payment return submission. */
    static final String RETURNS_PATH = "/returns";

    /** HTTP header FedNow uses to convey the JWS detached signature. */
    static final String JWS_HEADER = "X-JWS-Signature";

    private final String fednowEndpoint;
    private final RestTemplate restTemplate;

    /**
     * Creates a client with no retry behavior and no request signing. Test paths
     * against the WireMock simulator use this overload directly.
     */
    public HttpFedNowClient(String fednowEndpoint, int timeoutSeconds) {
        this(fednowEndpoint, timeoutSeconds, null, null);
    }

    /**
     * Compatibility constructor. The configured retry object is intentionally
     * unused for financial submissions with ambiguous network outcomes.
     */
    public HttpFedNowClient(String fednowEndpoint, int timeoutSeconds, Retry retry) {
        this(fednowEndpoint, timeoutSeconds, retry, null);
    }

    /**
     * Full constructor: endpoint, timeout, compatibility retry argument, and signer.
     *
     * <p>Neither transfer nor return submission retries after an ambiguous
     * response. A lost reply may follow a remote effect.
     *
     * <p>When a {@link FedNowJwsSigner} is provided, the client installs a
     * {@link ClientHttpRequestInterceptor} that computes a JWS detached signature
     * over the fully-serialized request body and attaches it as the
     * {@code X-JWS-Signature} HTTP header. Signing happens once per attempt
     * (including retries) because the body bytes are handed to the interceptor
     * on every call.
     *
     * <p>No rail-side idempotency guarantee is inferred from {@code EndToEndId}.
     * The public procedures describe a distinct message identifier and inquiry
     * process; this JSON endpoint is a synthetic transport, not a live mapping.
     *
     * @param fednowEndpoint base URL of the FedNow endpoint (no trailing slash)
     * @param timeoutSeconds connect and read timeout applied to every individual request
     * @param retry          retained for source compatibility, not applied
     * @param signer         JWS signer bean from {@code FedNowSigningConfig},
     *                       or {@code null} to send unsigned requests (sandbox / dev)
     */
    public HttpFedNowClient(String fednowEndpoint, int timeoutSeconds, Retry retry,
                            FedNowJwsSigner signer) {
        this.fednowEndpoint = fednowEndpoint;
        this.restTemplate = buildRestTemplate(timeoutSeconds);
        if (signer != null) {
            this.restTemplate.setInterceptors(List.of(new JwsSigningInterceptor(signer)));
            log.info("FedNow outbound signing active — every submission carries X-JWS-Signature");
        }
    }

    @Override
    public Pacs002Message submitCreditTransfer(Pacs008Message message) {
        String url = fednowEndpoint + TRANSFERS_PATH;
        log.info("Submitting pacs.008 to FedNow endpoint={}", url);
        // A transport failure cannot prove that the rail did not accept the
        // payment. Never retry a transfer automatically after an ambiguous send.
        try {
            Pacs002Message response = restTemplate.postForObject(url, message, Pacs002Message.class);
            if (response == null || response.getTransactionStatus() == null) {
                throw new SubmissionOutcomeUnknownException("Missing authoritative payment status", null);
            }
            return response;
        } catch (org.springframework.web.client.RestClientException e) {
            throw new SubmissionOutcomeUnknownException("Payment submission outcome unknown", e);
        }
    }

    @Override
    public Pacs002Message submitReturn(Pacs004Message message) {
        String url = fednowEndpoint + RETURNS_PATH;
        log.info("Submitting synthetic pacs.004-shaped return endpoint={} returnId={}",
                url, message.getReturnId());
        try {
            Pacs002Message response = restTemplate.postForObject(url, message, Pacs002Message.class);
            if (response == null || response.getTransactionStatus() == null
                    || !message.getOriginalEndToEndId().equals(response.getOriginalEndToEndId())
                    || !message.getOriginalTransactionId().equals(response.getOriginalTransactionId())) {
                throw new SubmissionOutcomeUnknownException("Return status missing or uncorrelated", null);
            }
            return response;
        } catch (org.springframework.web.client.RestClientException e) {
            throw new SubmissionOutcomeUnknownException("Return outcome unknown; do not retry blindly", e);
        }
    }

    private static RestTemplate buildRestTemplate(int timeoutSeconds) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(timeoutSeconds * 1000);
        factory.setReadTimeout(timeoutSeconds * 1000);

        // Register JavaTimeModule so OffsetDateTime fields in pacs.002 responses
        // deserialize correctly without Spring Boot's auto-configured ObjectMapper.
        ObjectMapper objectMapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        MappingJackson2HttpMessageConverter converter =
                new MappingJackson2HttpMessageConverter(objectMapper);

        RestTemplate restTemplate = new RestTemplate(factory);
        restTemplate.setMessageConverters(List.of(converter));
        return restTemplate;
    }

    /**
     * Adds the {@code X-JWS-Signature} header computed over the request body
     * by the injected {@link FedNowJwsSigner}. Applied on every attempt, so
     * a retry after a 5xx recomputes the signature — necessary because a
     * middlebox could rewrite the body (though FedNow forbids this in prod,
     * a defensive re-sign is cheap and correct).
     */
    static final class JwsSigningInterceptor implements ClientHttpRequestInterceptor {
        private final FedNowJwsSigner signer;

        JwsSigningInterceptor(FedNowJwsSigner signer) {
            this.signer = signer;
        }

        @Override
        public ClientHttpResponse intercept(HttpRequest request, byte[] body,
                                            ClientHttpRequestExecution execution) throws IOException {
            String jws = signer.sign(body);
            request.getHeaders().set(JWS_HEADER, jws);
            return execution.execute(request, body);
        }
    }
}
